#include "game.h"

Player player;
Projectile projectiles[PROJECTILE_MAX];
Brick bricks[BRICK_COLUMNS][BRICK_ROWS];
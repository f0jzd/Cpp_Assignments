#pragma once
#include <SDL/SDL.h>


extern SDL_Window* window;
extern SDL_Renderer* render;

extern bool keys[SDL_NUM_SCANCODES];

extern float delta_time;

